import java.math.BigDecimal;

public class nonIT extends Staff {
    public nonIT(String dpt, BigDecimal salary, String title, boolean exec) {
        super(dpt, salary, title, exec);
    }
}
