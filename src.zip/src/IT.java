import java.math.BigDecimal;

public class IT extends Staff{

    public IT(String dpt, BigDecimal salary, String title, boolean exec) {
        super(dpt, salary, title, exec);
    }
}
